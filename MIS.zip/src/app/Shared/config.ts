export class DIAConfig {
    public static apiUrl:string="http://sbi-706173083.us-west-2.elb.amazonaws.com/mis";
  //  public static apiUrl:string="https://10.209.74.71:7002/misuat";
 // public static apiUrl:string="https://mobile.onlinesbi.com/misuat";
}