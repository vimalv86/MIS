export class FilterVal {
    name: string = null;
    code: string = null;
}