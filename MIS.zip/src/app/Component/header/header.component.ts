import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MISUserInfoService } from '../../Service/User/userInfo.service';
import { Cookie } from 'ng2-cookies/ng2-cookies';

@Component({
  selector: 'mis-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [
  MISUserInfoService
  ]
})
export class HeaderComponent implements OnInit {
  private apiRequest: any;
  private pfId: any;
  private userInfo: any;
  private password: string;
  private message: string;
  private lastLogin: any;

  constructor(private service: MISUserInfoService, private route: ActivatedRoute) {}
  ngOnInit() {
    this.message = '';
    // if (Cookie.get('PFID') && Cookie.get('PFID') != null && Cookie.get('PFID') != "null") {
    // this.pfId = Cookie.get('PFID');
    // this.apiRequest = { "pfId": this.pfId, "invokedFrom": "login"};
    localStorage.setItem("isPFIDAvailable", "true");
    this.pfId = 1100024;
    //this.password = "hrmS@123";
    this.apiRequest = { "pfId": this.pfId,  "invokedFrom": "login" };
    this.lastLogin = new Date();
    this.service.getUserInfo(this.apiRequest).subscribe(response => {
      if (response && response.user) {
          this.userInfo = response;
          console.log(this.userInfo);
        
      } else {
        this.message = "You don't have access to MIS Application, Please raise a request in MIS User Management Portal";
        console.log("Error");
      }
    })
    // } else {
    //   localStorage.setItem("isPFIDAvailable", "false");
    //   this.message = "You don't have access to MIS Application, Please raise a request in DIA User Management Portal";
    // }
  }
  logout() {
    localStorage.setItem("isPFIDAvailable", "false");
    window.location.href  =  'https://mobile.onlinesbi.com/DIAMISUAT/logout';
  }

}