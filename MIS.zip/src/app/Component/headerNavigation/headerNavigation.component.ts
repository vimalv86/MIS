import { Component } from '@angular/core';

@Component({
    selector: 'header-nav',
    templateUrl: './headerNavigation.component.html',
    styleUrls: ['./headerNavigation.component.scss']
})

export class HeaderNavigationComponent {
    
}