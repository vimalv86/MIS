import { Component, OnInit, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'sub-nav',
  templateUrl: './subNavigation.component.html',
  styleUrls: ['./subNavigation.component.scss']
})

export class SubNavigationComponent implements OnInit {
  private moduleUrl: string = null;

  constructor(@Inject(DOCUMENT) private document: Document) {
    let baseAppUrl = (this.document.location.href).split('#');
    let splitUrl = baseAppUrl[1].split('/');
    this.moduleUrl = splitUrl[1] + '/' + splitUrl[2];
  }

  ngOnInit(){
    console.log(this.moduleUrl);
  }
}