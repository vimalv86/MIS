import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class InspectionDoneCountService {

  private inspectionDoneCountSource = new BehaviorSubject<Number>(0);
  inspectionDoneCount = this.inspectionDoneCountSource.asObservable();

  constructor() { }

  changeInspectionDoneCount(inspectionDoneCount: Number) {
    this.inspectionDoneCountSource.next(inspectionDoneCount);
  }

}