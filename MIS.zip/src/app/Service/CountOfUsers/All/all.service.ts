import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';

import { InspectionDoneCountService } from '../../../Service/inspectionDoneCount.service';
import { DIAConfig } from '../../../Shared/config';

@Injectable()
export class AllSegmentService {
    circleUrl = DIAConfig.apiUrl + "/branch/getCircle";
    networkUrl = DIAConfig.apiUrl + "/branch/getNetwork";
    moduleUrl = DIAConfig.apiUrl + "/branch/getModule";
    regionUrl = DIAConfig.apiUrl + "/branch/getRegion";
    branchUrl = DIAConfig.apiUrl + "/branch/getBranchCodeList";
    userCountUrl = DIAConfig.apiUrl + "/users/getuserslist";
    downloadPDFUrl = DIAConfig.apiUrl + "/download/cou/pdf?downloadfor=cou";
    downloadCSVUrl = DIAConfig.apiUrl + "/download/cou/csv?downloadfor=cou";
   //downloadCSVUrl = "https://mobile.onlinesbi.com/misuat/download/cou/csv?downloadfor=cou";
    constructor(private http: Http, private iDoneCountService: InspectionDoneCountService) { }

    public getCircleListDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.circleUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });

    }

    public getNetworkListDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.networkUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });

    }

    public getModuleListDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.moduleUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });

    }

    public getRegionListDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.regionUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });

    }

     public getBranchListDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.branchUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });

    }

    public getCountOfUserDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.userCountUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                this.iDoneCountService.changeInspectionDoneCount(result.count);
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });
    }

    public downloadPDFDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.downloadPDFUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });
    }

    public downloadCSVDetails(data:any): Observable<any> {
       console.log(data);
            return this.http.post(this.downloadCSVUrl, data , null)
            .map(response => {
                console.log("Success");
                let result: any = response.json();
                console.log(result);
                return result;
            })
            .catch(response => {
                console.log("Error");
                return "Error";
            });
    }
}