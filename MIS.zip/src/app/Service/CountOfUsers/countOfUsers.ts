export class CountOfUsers {
    nameOfUnit: string = null;
    circleName: string = null;
}