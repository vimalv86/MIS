import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { HttpModule, Http, RequestOptions, XHRBackend } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { HashLocationStrategy, LocationStrategy } from "@angular/common";
//Common component
import { AppComponent } from './app.component';
import { SpinnerComponent } from '../app/Component/Spinner/spinner.component';
import { HeaderComponent } from '../app/Component/Header/header.component';
import { FooterComponent } from '../app/Component/Footer/footer.component';
import { HeaderNavigationComponent } from '../app/Component/HeaderNavigation/headerNavigation.component';
import { FooterNavigationComponent } from '../app/Component/FooterNavigation/footerNavigation.component';
import { CountOfUsersComponent } from '../app/Module/CountOfUsers/countOfUsers.component';
import { ActiveAndInactiveComponent } from '../app/Module/ActiveAndInactive/activeAndInactive.component';
import { InspectionDoneComponent } from '../app/Module/InspectionDone/inspectionDone.component';
import { SubNavigationComponent } from '../app/Component/subNavigation/subNavigation.component';
import { GridViewComponent } from '../app/Module/CountOfUsers/GridView/gridView.component';
import { GraphViewComponent } from '../app/Module/CountOfUsers/GraphView/graphView.component';
import { AllGridViewComponent } from '../app/Module/CountOfUsers/GridView/All/all.component';
import { SMEGridViewComponent } from '../app/Module/CountOfUsers/GridView/SME/SME.component';

import { ActiveAndInactiveGridViewComponent } from '../app/Module/ActiveAndInactive/GridView/gridView.component';
import { ActiveAndInactiveGraphViewComponent } from '../app/Module/ActiveAndInactive/GraphView/graphView.component';
import { ActiveAndInactiveAllGridViewComponent } from '../app/Module/ActiveAndInactive/GridView/All/all.component';
import { ActiveAndInactiveSMEGridViewComponent } from '../app/Module/ActiveAndInactive/GridView/SME/SME.component';
import { InspectionDoneGridViewComponent } from '../app/Module/InspectionDone/GridView/gridView.component';
import { InspectionDoneGraphViewComponent } from '../app/Module/InspectionDone/GraphView/graphView.component';
import { InspectionDoneAllGridViewComponent } from '../app/Module/InspectionDone/GridView/All/all.component';
import { InspectionDoneSMEGridViewComponent } from '../app/Module/InspectionDone/GridView/SME/SME.component';
//Routing
import { routes } from './Routing/app.routing';

import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
import { MomentModule } from 'angular2-moment';

//Spinner
import { HttpService } from './Core/http.service';
import { HttpFactory } from './Core/http.factory';

//PrimeNg
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  CalendarModule,
  DropdownModule,
  ButtonModule,
  DataTableModule,
  SharedModule,
  PaginatorModule,
  MessagesModule,
  MessageModule,
  ChartModule
} from 'primeng/primeng';
//import { ChartModule } from 'primeng/chart';
import { InspectionDoneSMEGraphViewComponent } from './Module/InspectionDone/GraphView/SME/SME.component';
import { InspectionDoneAllGraphViewComponent } from './Module/InspectionDone/GraphView/All/all.component';



@NgModule({
  declarations: [
    AppComponent,
    SpinnerComponent,
    HeaderComponent,
    FooterComponent,
    HeaderNavigationComponent,
    FooterNavigationComponent,
    CountOfUsersComponent,
    ActiveAndInactiveComponent,
    InspectionDoneComponent,
    SubNavigationComponent,
    GridViewComponent,
    GraphViewComponent,
    AllGridViewComponent,
    SMEGridViewComponent,
    ActiveAndInactiveGridViewComponent,
    ActiveAndInactiveGraphViewComponent,
    ActiveAndInactiveAllGridViewComponent,
    ActiveAndInactiveSMEGridViewComponent,
    InspectionDoneGridViewComponent,
    InspectionDoneGraphViewComponent,
    InspectionDoneAllGridViewComponent,
    InspectionDoneSMEGridViewComponent,
    InspectionDoneAllGraphViewComponent,
    InspectionDoneSMEGraphViewComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    HttpClientModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    DropdownModule,
    CalendarModule,
    ButtonModule,
    DataTableModule, 
    SharedModule,
    PaginatorModule,
    MessagesModule,
    MessageModule,
    ChartModule,
    MomentModule,
    NgIdleKeepaliveModule.forRoot()
  ],
  providers: [
     {
      provide: Http, useFactory: HttpFactory,
      deps: [XHRBackend, RequestOptions]
    },
    {
      provide: LocationStrategy, 
      useClass: HashLocationStrategy}, 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
