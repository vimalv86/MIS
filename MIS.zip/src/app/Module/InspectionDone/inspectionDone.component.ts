import { Component, OnInit  } from '@angular/core';
import { InspectionDoneCountService } from '../../Service/inspectionDoneCount.service';

@Component({
    selector: 'inspectionDone',
    templateUrl: './inspectionDone.component.html',
    styleUrls: ['./inspectionDone.component.scss', '../module.component.scss'],
    providers: [
      InspectionDoneCountService
    ]
})

export class InspectionDoneComponent implements OnInit {
  public count:Number;
  
    constructor(private data: InspectionDoneCountService) { }
  
    ngOnInit() {
      this.data.inspectionDoneCount.subscribe(count => this.count = count);
    }
}