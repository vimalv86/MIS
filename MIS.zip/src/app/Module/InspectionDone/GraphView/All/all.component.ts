import { Component, OnInit, ViewChild } from '@angular/core';

import { FilterVal } from '../../../../Shared/filterVal';
import { AllSegmentService } from '../../../../Service/InspectionDone/All/all.service';
import { PaginatorModule, Paginator } from 'primeng/primeng';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'all',
  templateUrl: './all.component.html',
  styleUrls: ['./all.component.scss', '../../../module.component.scss'],
  providers: [
    FilterVal,
    AllSegmentService
  ]
})

export class InspectionDoneAllGraphViewComponent implements OnInit {
  @ViewChild('paginatorVal') paginator: Paginator;
  private userList: any[];
  private circle: FilterVal[];
  private network: FilterVal[];
  private module: FilterVal[];
  private region: FilterVal[];
  private branch: FilterVal[];
  private apiRequest: any;
  private circleName: any;
  private networkName: any;
  private moduleName: any;
  private regionName: any;
  private branchName: any;
  private isNetworkDisabled: boolean = true;
  private isModuleDisabled: boolean = true;
  private isRegionDisabled: boolean = true;
  private isBranchDisabled: boolean = true;
  private fromDate: any;
  private toDate: any;
  private rangeDates: any;
  private dateValMsg: string;
  private isValidationComplete: boolean = true;
  private totalRecords: any;
  private offset: any = 1;
  private limit: any = 10;
  private rowNo: any = 1;
  private maximumToDate: any;
  private maximumFromDate: any;
  private inspectionType: any;
  private inspectionStatus: any;
  private type: any = [];
  private status: any = [];
  private isPFIDAvailable: boolean = true;

  private data: any;
  private bgColor: any = [];
  private options: any;

  constructor(private service: AllSegmentService) {
    this.maximumToDate = new Date();
    this.maximumFromDate = new Date();
    if (localStorage.getItem("isPFIDAvailable") == "true") {
      this.isPFIDAvailable = true;
    } else {
      this.isPFIDAvailable = false;
    }
    this.type = ["Pre Sanction", "Post Sanction"];
    this.status = ["Incomplete", "Web Incomplete", "Pending For Review", "Accepted", "Rejected"];
  }

  ngOnInit() {
    this.getCircleList();
  }
  getCircleList() {
    this.apiRequest = {};

    this.service.getCircleListDetails(this.apiRequest).subscribe(response => {
      if (response) {
        this.circle = response;
        for(let i=0; i<this.circle.length; i++) {
          this.bgColor.push('#'+(Math.random()*0xFFFFFF<<0).toString(16));
        }
        this.data = {
          labels: this.circle,
          datasets: [
            {
              data: [300, 50, 100, 30, 70, 20, 10],
              backgroundColor: this.bgColor,
              hoverBackgroundColor: this.bgColor
            }
          ]
        }
        this.options = {
          legend: {
              position: 'bottom'
          }
        };
      }

    })
  }

}