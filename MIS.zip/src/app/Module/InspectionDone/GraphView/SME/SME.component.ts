import { Component, OnInit, ViewChild } from '@angular/core';

import { FilterVal } from '../../../../Shared/filterVal';
import { AllSegmentService } from '../../../../Service/InspectionDone/All/all.service';
import { PaginatorModule, Paginator } from 'primeng/primeng';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'SME',
  templateUrl: './SME.component.html',
  styleUrls: ['./SME.component.scss', '../../../module.component.scss'],
  providers: [
    FilterVal,
    AllSegmentService
  ]
})

export class InspectionDoneSMEGraphViewComponent implements OnInit {
  @ViewChild('paginatorVal') paginator: Paginator;
  private userList: any[];
  private circle: FilterVal[];
  private network: FilterVal[];
  private module: FilterVal[];
  private region: FilterVal[];
  private branch: FilterVal[];
  private apiRequest: any;
  private circleName: any;
  private networkName: any;
  private moduleName: any;
  private regionName: any;
  private branchName: any;
  private isNetworkDisabled: boolean = true;
  private isModuleDisabled: boolean = true;
  private isRegionDisabled: boolean = true;
  private isBranchDisabled: boolean = true;
  private fromDate: any;
  private toDate: any;
  private rangeDates: any;
  private dateValMsg: string;
  private isValidationComplete: boolean = true;
  private totalRecords: any;
  private offset: any = 1;
  private limit: any = 10;
  private rowNo: any = 1;
  private inspectionType: any;
  private maximumToDate: any;
  private maximumFromDate: any;
  private inspectionStatus: any;
  private type: any = [];
  private status: any = [];
  private isPFIDAvailable: boolean = true;

  constructor(private service: AllSegmentService) {
    this.maximumToDate = new Date();
    this.maximumFromDate = new Date();
    if (localStorage.getItem("isPFIDAvailable") == "true") {
      this.isPFIDAvailable = true;
    } else {
      this.isPFIDAvailable = false;
    }
    this.type = ["Pre Sanction", "Post Sanction"];
    this.status = ["Incomplete", "Web Incomplete", "Pending For Review", "Accepted", "Rejected"];
  }

  ngOnInit() {
  }
}