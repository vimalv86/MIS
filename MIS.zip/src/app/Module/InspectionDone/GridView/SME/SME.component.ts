import { Component, OnInit, ViewChild } from '@angular/core';

import { FilterVal } from '../../../../Shared/filterVal';
import { AllSegmentService } from '../../../../Service/InspectionDone/All/all.service';
import { PaginatorModule, Paginator } from 'primeng/primeng';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'SME',
  templateUrl: './SME.component.html',
  styleUrls: ['./SME.component.scss', '../../../module.component.scss'],
  providers: [
    FilterVal,
    AllSegmentService
  ]
})

export class InspectionDoneSMEGridViewComponent implements OnInit {
  @ViewChild('paginatorVal') paginator: Paginator;
  private userList: any[];
  private circle: FilterVal[];
  private network: FilterVal[];
  private module: FilterVal[];
  private region: FilterVal[];
  private branch: FilterVal[];
  private apiRequest: any;
  private circleName: any;
  private networkName: any;
  private moduleName: any;
  private regionName: any;
  private branchName: any;
  private isNetworkDisabled: boolean = true;
  private isModuleDisabled: boolean = true;
  private isRegionDisabled: boolean = true;
  private isBranchDisabled: boolean = true;
  private fromDate: any;
  private toDate: any;
  private rangeDates: any;
  private dateValMsg: string;
  private isValidationComplete: boolean = true;
  private totalRecords: any;
  private offset: any = 1;
  private limit: any = 10;
  private rowNo: any = 1;
  private inspectionType: any;
  private maximumToDate: any;
  private maximumFromDate: any;
  private inspectionStatus: any;
  private type: any = [];
  private status: any = [];
  private isPFIDAvailable: boolean = true;

  constructor(private service: AllSegmentService) {
    this.maximumToDate = new Date();
    this.maximumFromDate = new Date();
    if (localStorage.getItem("isPFIDAvailable") == "true") {
      this.isPFIDAvailable = true;
    } else {
      this.isPFIDAvailable = false;
    }
    this.type = ["Pre Sanction", "Post Sanction"];
    this.status = ["Accepted", "Incomplete", "Pending For Review", "Rejected", "Web Incomplete"];
  }

  ngOnInit() {
    this.circleName = '';
    this.networkName = null;
    this.moduleName = '';
    this.regionName = null;
    this.branchName = '';
    this.inspectionType = null;
    this.fromDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.toDate = new Date();
    this.getCircleList();
    this.getInspectionDoneData();
  }

  getCircleList() {
    this.apiRequest = {};

    this.service.getCircleListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.circle = [];
      for (let k = 0; k < response.length; k++) {
        let circleObj = { name: response[k], code: response[k] }
        this.circle.push(circleObj);
      }
    })
  }

  getNetworkList() {
    this.apiRequest = { "circlename": this.circleName };

    this.service.getNetworkListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.network = [];
      this.network.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let networkObj = { name: "Network " + response[k], code: response[k] }
        this.network.push(networkObj);
      }
    })
  }

  getModuleList() {
    this.apiRequest = { "circlename": this.circleName, "network": this.networkName }

    this.service.getModuleListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.module = [];
      this.module.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let moduleObj = { name: response[k], code: response[k] }
        this.module.push(moduleObj);
      }
    })
  }

  getRegionList() {
    this.apiRequest = { "circlename": this.circleName, "network": this.networkName, "module": this.moduleName }

    this.service.getRegionListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.region = [];
      this.region.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let regionObj = { name: "Region " + response[k], code: response[k] }
        this.region.push(regionObj);
      }
    })
  }

  getBranchList() {
    this.apiRequest = { "circlename": this.circleName, "network": this.networkName, "module": this.moduleName, "regionId": this.regionName }

    this.service.getBranchListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.branch = [];
      this.branch.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let branchObj = { name: response[k], code: response[k] }
        this.branch.push(branchObj);
      }
    })
  }

  searchNetwork(circleName) {
    this.circleName = circleName;
    this.moduleName = '';
    this.regionName = null;
    this.branchName = '';
    this.getNetworkList();
    if (circleName == "All") {
      this.networkName = null;
      this.isNetworkDisabled = true;
    } else {
      this.networkName = 'All';
      this.isNetworkDisabled = false;
    }
    this.isModuleDisabled = true;
    this.isRegionDisabled = true;
    this.isBranchDisabled = true;
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  searchModule(networkName) {
    this.networkName = +(networkName.replace("Network", ''));
    this.regionName = null;
    this.branchName = '';
    this.getModuleList();
    if (networkName == "All") {
      this.isModuleDisabled = true;
      this.moduleName = '';
    } else {
      this.isModuleDisabled = false;
      this.moduleName = 'All';
    }
    this.isRegionDisabled = true;
    this.isBranchDisabled = true;
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  searchRegion(moduleName) {
    this.moduleName = moduleName;
    this.branchName = '';
    this.getRegionList();
    if (moduleName == "All") {
      this.isRegionDisabled = true;
      this.regionName = null;
    } else {
      this.isRegionDisabled = false;
      this.regionName = 'All';
    }
    this.isBranchDisabled = true;
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  searchBranch(regionName) {
    this.regionName = +(regionName.replace("Region", ''));
    this.getBranchList();
    if (regionName == "All") {
      this.isBranchDisabled = true;
      this.branchName = '';
    } else {
      this.isBranchDisabled = false;
      this.branchName = 'All';
    }
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  selectBranch(branchName) {
    this.branchName = branchName;
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  typeSelection(typeName) {
    this.inspectionType = typeName;
    if (this.inspectionType == "All") {
      this.inspectionType = null;
    }
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  statusSelection(statusName) {
    this.inspectionStatus = statusName;
    if (this.inspectionStatus == "All") {
      this.inspectionStatus = null;
    } else if (this.inspectionStatus == "Pending For Review") {
      this.inspectionStatus = "PendingForReview";
    } else if (this.inspectionStatus == "Web Incomplete") {
      this.inspectionStatus = "WebIncomplete";
    } else if (this.inspectionStatus == "Mob Incomplete") {
      this.inspectionStatus = "MobIncomplete";
    }
    this.paginator.changePageToFirst(event);
    this.getInspectionDoneData();
  }

  searchData() {
    this.offset = 1;
    this.getInspectionDoneData();
  }

  clearData() {
    this.isNetworkDisabled = true;
    this.isModuleDisabled = true;
    this.isRegionDisabled = true;
    this.isBranchDisabled = true;
    this.circleName = '';
    this.networkName = null;
    this.moduleName = '';
    this.regionName = null;
    this.branchName = '';
    this.inspectionType = '';
    this.inspectionStatus = '';
    this.offset = 1;
    this.rowNo = 1;
    this.paginator.changePageToFirst(event);
    this.fromDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.toDate = new Date();
    this.getInspectionDoneData();
  }

  getInspectionDoneData() {
    if (this.isValidationComplete) {
      this.apiRequest = { "limit": this.limit, "offset": this.offset, "sort_by": "status", "order_by": "asc" };
      if (this.circleName && this.circleName != "All") {
        this.apiRequest.circleName = this.circleName;
      } else {
        this.apiRequest.circleName = null;
      }
      if (this.moduleName && this.moduleName != "All") {
        this.apiRequest.moduleName = this.moduleName;
      } else {
        this.apiRequest.moduleName = null;
      }
      if (this.networkName && this.networkName != "All") {
        this.apiRequest.networkId = this.networkName;
      } else {
        if (this.networkName != null && this.networkName.toString() == "0") {
          this.apiRequest.networkId = this.networkName;
        } else {
          this.apiRequest.networkId = null;
        }
      }
      if (this.regionName && this.regionName != "All") {
        this.apiRequest.regId = this.regionName;
      } else {
        if (this.regionName != null && this.regionName.toString() == "0") {
          this.apiRequest.regId = this.regionName;
        } else {
          this.apiRequest.regId = null;
        }
      }
      if (this.branchName && this.branchName != "All") {
        this.apiRequest.branchCode = this.branchName;
      } else {
        this.apiRequest.branchCode = null;
      }
      if (this.inspectionType) {
        this.apiRequest.type = this.inspectionType;
      } else {
        this.apiRequest.type = null;
      }
      if (this.inspectionStatus) {
        this.apiRequest.status = this.inspectionStatus;
      } else {
        this.apiRequest.status = null;
      }
      if (this.fromDate) {
        this.apiRequest.fromDate = new Date(this.fromDate).getTime();
      }
      if (this.toDate) {
        this.apiRequest.toDate = new Date(this.toDate).getTime();
      }

      this.service.getCountOfUserDetails(this.apiRequest).subscribe(response => {
        console.log(response);
        if (response) {
          let userListTemp = [];
          this.userList = response.inspectionList;
          this.totalRecords = response.totalCount;
          for (let k = 0; k < this.userList.length; k++) {
            this.userList[k].id = parseInt(this.userList[k].id);
          }
        }
      })
    } else {
      this.isValidationComplete = false;
      this.dateValMsg = 'From Date should be less than To Date';
      this.setTimeOut();
    }
  }

  selectFromDate(fromDate) {
    let dateFromAndTo = fromDate;
    let dateConversion = new Date(dateFromAndTo);
    this.maximumToDate = new Date(dateConversion.setDate(dateConversion.getDate() + 365));
    if (this.maximumToDate > new Date()) {
      this.maximumToDate = new Date();
    }
    if (this.toDate > this.maximumToDate) {
      this.toDate = this.maximumToDate;
    }
    if (this.fromDate > this.toDate) {
      this.isValidationComplete = false;
      this.dateValMsg = 'From Date should be less than To Date';
      this.setTimeOut();
    } else {
      this.isValidationComplete = true;
      this.paginator.changePageToFirst(event);
      this.getInspectionDoneData();
    }
  }

  selectToDate(toDate) {
    this.toDate = this.toDate.setDate(toDate.getDate() + 1);
    if (this.fromDate > this.toDate) {
      this.isValidationComplete = false;
      this.dateValMsg = 'From Date should be less than To Date';
      this.setTimeOut();
    } else {
      this.isValidationComplete = true;
      this.paginator.changePageToFirst(event);
      this.getInspectionDoneData();
    }
  }

  paginate(event) {
    const mainDiv = document.getElementById('content-wrapper');
    if (mainDiv) {
      setTimeout(function () {
        mainDiv.scrollTop = 0;
      }, 1)
    }
    this.rowNo = event.first + 1;
    this.offset = event.page + 1;
    this.getInspectionDoneData();
  }

  setTimeOut() {
    setTimeout(() => {
      this.dateValMsg = "";
    }, 3000);
  }

  downloadPDF() {
    this.downloadFile();
    this.service.downloadPDFDetails(this.apiRequest).subscribe(response => {
      if (response) {
        var byteCharacters = atob(response.file);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: 'application/pdf' });
        var filename = 'CountOfUsers_All.pdf';
        var fileURL = URL.createObjectURL(blob);
        window.open(fileURL); // if you want to open it in new tab
        FileSaver.saveAs(blob, filename);
      }
    })
  }

  downloadCSV() {
    this.downloadFile();
    this.service.downloadCSVDetails(this.apiRequest).subscribe(response => {
      if (response) {
        var byteCharacters = atob(response.res);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: 'application/csv' });
        var filename = 'NoOfInspectionDone_SME.csv';
        var fileURL = URL.createObjectURL(blob);
        window.open(fileURL); // if you want to open it in new tab
        FileSaver.saveAs(blob, filename);
      }
    })
  }

  downloadFile() {
    this.apiRequest = { "sort_by": "status", "order_by": "asc" };
    if (this.inspectionType) {
      this.apiRequest.type = this.inspectionType;
    } else {
      this.apiRequest.type = null;
    }
    if (this.circleName && this.circleName != "All") {
      this.apiRequest.circleName = this.circleName;
    } else {
      this.apiRequest.circleName = null;
    }
    if (this.moduleName && this.moduleName != "All") {
      this.apiRequest.moduleName = this.moduleName;
    } else {
      this.apiRequest.moduleName = null;
    }
    if (this.networkName && this.networkName != "All") {
      this.apiRequest.networkId = this.networkName;
    } else {
      if (this.networkName != null && this.networkName.toString() == "0") {
        this.apiRequest.networkId = this.networkName;
      } else {
        this.apiRequest.networkId = null;
      }
    }
    if (this.regionName && this.regionName != "All") {
      this.apiRequest.regId = this.regionName;
    } else {
      if (this.regionName != null && this.regionName.toString() == "0") {
        this.apiRequest.regId = this.regionName;
      } else {
        this.apiRequest.regId = null;
      }
    }
    if (this.branchName && this.branchName != "All") {
      this.apiRequest.branchCode = this.branchName;
    } else {
      this.apiRequest.branchCode = null;
    }
    if (this.fromDate) {
      this.apiRequest.fromDate = new Date(this.fromDate).getTime();
    }
    if (this.toDate) {
      this.apiRequest.toDate = new Date(this.toDate).getTime();
    }
  }

}