import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'graph-view',
    templateUrl: './graphView.component.html',
    styleUrls: ['./graphView.component.scss', '../../module.component.scss']
})

export class GraphViewComponent {
    
}