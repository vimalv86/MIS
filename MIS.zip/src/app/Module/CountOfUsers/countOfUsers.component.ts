import { Component, OnInit } from '@angular/core';
import { InspectionDoneCountService } from '../../Service/inspectionDoneCount.service';


@Component({
    selector: 'countOfUsers',
    templateUrl: './countOfUsers.component.html',
    styleUrls: ['./countOfUsers.component.scss', '../module.component.scss'],
    providers: [
      InspectionDoneCountService
    ]
})

export class CountOfUsersComponent implements OnInit  {
  public count:Number;
  
    constructor(private data: InspectionDoneCountService) { }
  
    ngOnInit() {
      this.data.inspectionDoneCount.subscribe(count => this.count = count);
    }
}