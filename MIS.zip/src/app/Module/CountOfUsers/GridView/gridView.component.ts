import { Component, OnInit } from '@angular/core';

import { CountOfUsers } from '../../../Service/CountOfUsers/countOfUsers';
import { FilterVal } from '../../../Shared/filterVal';

@Component({
  selector: 'grid-view',
  templateUrl: './gridView.component.html',
  styleUrls: ['./gridView.component.scss', '../../module.component.scss'],
  providers: [
    CountOfUsers,
    FilterVal
  ]
})

export class GridViewComponent implements OnInit {
  private cols: any[];

  ngOnInit() {
  }
}