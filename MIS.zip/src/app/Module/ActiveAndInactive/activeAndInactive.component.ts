import { Component } from '@angular/core';
import { InspectionDoneCountService } from '../../Service/inspectionDoneCount.service';

@Component({
    selector: 'activeAndInactive',
    templateUrl: './activeAndInactive.component.html',
    styleUrls: ['./activeAndInactive.component.scss', '../module.component.scss'],
    providers: [
      InspectionDoneCountService
    ]
})

export class ActiveAndInactiveComponent {
  public count:Number;
  
    constructor(private data: InspectionDoneCountService) { }
  
    ngOnInit() {
      this.data.inspectionDoneCount.subscribe(count => this.count = count);
    }
}