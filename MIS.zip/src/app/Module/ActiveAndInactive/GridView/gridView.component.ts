import { Component, OnInit } from '@angular/core';

import { FilterVal } from '../../../Shared/filterVal';

@Component({
  selector: 'grid-view',
  templateUrl: './gridView.component.html',
  styleUrls: ['./gridView.component.scss', '../../module.component.scss'],
  providers: [
    FilterVal
  ]
})

export class ActiveAndInactiveGridViewComponent implements OnInit {
  private cols: any[];

  ngOnInit() {

  }
}