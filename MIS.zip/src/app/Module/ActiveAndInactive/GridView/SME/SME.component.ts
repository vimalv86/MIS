import { Component, OnInit, ViewChild } from '@angular/core';

import { CountOfUsers } from '../../../../Service/CountOfUsers/countOfUsers';
import { FilterVal } from '../../../../Shared/filterVal';
import { AllSegmentService } from '../../../../Service/ActiveAndInactive/All/all.service';
import { PaginatorModule, Paginator } from 'primeng/primeng';
import * as FileSaver from 'file-saver';

@Component({
  selector: 'SME',
  templateUrl: './SME.component.html',
  styleUrls: ['./SME.component.scss', '../../../module.component.scss'],
  providers: [
    CountOfUsers,
    FilterVal,
    AllSegmentService
  ]
})

export class ActiveAndInactiveSMEGridViewComponent implements OnInit {
  @ViewChild('paginatorVal') paginator: Paginator;
  private userList: any[];
  private circle: FilterVal[];
  private network: FilterVal[];
  private module: FilterVal[];
  private region: FilterVal[];
  private branch: FilterVal[];
  private apiRequest: any;
  private circleName: any;
  private networkName: any;
  private moduleName: any;
  private regionName: any;
  private branchName: any;
  private isNetworkDisabled: boolean = true;
  private isModuleDisabled: boolean = true;
  private isRegionDisabled: boolean = true;
  private isBranchDisabled: boolean = true;
  private fromDate: any;
  private toDate: any;
  private rangeDates: any;
  private dateValMsg: string;
  private isValidationComplete: boolean = true;
  private totalRecords: any;
  private offset: any = 1;
  private limit: any = 10;
  private rowNo: any = 1;
  private maximumDate: any;
  private statusType: any;
  private status: any = [];
  private isNeverLoggedIn: boolean = false;
  private isPFIDAvailable: boolean = true;
  private maximumToDate: any;
  private maximumFromDate: any;
  private fileName: any;

  constructor(private service: AllSegmentService) {
    this.maximumToDate = new Date();
    this.maximumFromDate = new Date();
    if (localStorage.getItem("isPFIDAvailable") == "true") {
      this.isPFIDAvailable = true;
    } else {
      this.isPFIDAvailable = false;
    }
    this.status = ["Inspections Not Done", "Logged in Users", "Never Logged in Users", "Not Logged in Users"];
  }

  ngOnInit() {
    this.circleName = '';
    this.networkName = null;
    this.moduleName = '';
    this.regionName = null;
    this.branchName = '';
    this.statusType = 'Inspections Done';
    this.fromDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.toDate = new Date();
    this.getCircleList();
    this.setRequestBody();
  }

  getCircleList() {
    this.apiRequest = {};

    this.service.getCircleListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.circle = [];
      for (let k = 0; k < response.length; k++) {
        let circleObj = { name: response[k], code: response[k] }
        this.circle.push(circleObj);
      }
    })
  }

  getNetworkList() {
    this.apiRequest = { "circlename": this.circleName };

    this.service.getNetworkListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.network = [];
      this.network.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let networkObj = { name: "Network " + response[k], code: response[k] }
        this.network.push(networkObj);
      }
    })
  }

  getModuleList() {
    this.apiRequest = { "circlename": this.circleName, "network": this.networkName }

    this.service.getModuleListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.module = [];
      this.module.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let moduleObj = { name: response[k], code: response[k] }
        this.module.push(moduleObj);
      }
    })
  }

  getRegionList() {
    this.apiRequest = { "circlename": this.circleName, "network": this.networkName, "module": this.moduleName }

    this.service.getRegionListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.region = [];
      this.region.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let regionObj = { name: "Region " + response[k], code: response[k] }
        this.region.push(regionObj);
      }
    })
  }

  getBranchList() {
    this.apiRequest = { "circlename": this.circleName, "network": this.networkName, "module": this.moduleName, "regionId": this.regionName }

    this.service.getBranchListDetails(this.apiRequest).subscribe(response => {
      console.log(response);
      this.branch = [];
      this.branch.push({ name: "All", code: "All" });
      for (let k = 0; k < response.length; k++) {
        let branchObj = { name: response[k], code: response[k] }
        this.branch.push(branchObj);
      }
    })
  }

  searchNetwork(circleName) {
    this.circleName = circleName;
    this.moduleName = '';
    this.regionName = null;
    this.branchName = '';
    this.getNetworkList();
    if (circleName == "All") {
      this.networkName = null;
      this.isNetworkDisabled = true;
    } else {
      this.networkName = 'All';
      this.isNetworkDisabled = false;
    }
    this.isModuleDisabled = true;
    this.isRegionDisabled = true;
    this.isBranchDisabled = true;
    this.paginator.changePageToFirst(event);
    this.setRequestBody();
  }

  searchModule(networkName) {
    this.networkName = +(networkName.replace("Network", ''));
    this.regionName = null;
    this.branchName = '';
    this.getModuleList();
    if (networkName == "All") {
      this.isModuleDisabled = true;
      this.moduleName = '';
    } else {
      this.isModuleDisabled = false;
      this.moduleName = 'All';
    }
    this.isRegionDisabled = true;
    this.isBranchDisabled = true;
    this.paginator.changePageToFirst(event);
    this.setRequestBody();
  }

  searchRegion(moduleName) {
    this.moduleName = moduleName;
    this.branchName = '';
    this.getRegionList();
    if (moduleName == "All") {
      this.isRegionDisabled = true;
      this.regionName = null;
    } else {
      this.isRegionDisabled = false;
      this.regionName = 'All';
    }
    this.isBranchDisabled = true;
    this.paginator.changePageToFirst(event);
    this.setRequestBody();
  }

  searchBranch(regionName) {
    this.regionName = +(regionName.replace("Region", ''));
    this.getBranchList();
    if (regionName == "All") {
      this.isBranchDisabled = true;
      this.branchName = '';
    } else {
      this.isBranchDisabled = false;
      this.branchName = 'All';
    }
    this.paginator.changePageToFirst(event);
    this.setRequestBody();
  }

  selectBranch(branchName) {
    this.branchName = branchName;
    this.paginator.changePageToFirst(event);
    this.setRequestBody();
  }

  statusSelection(statusName) {
    this.statusType = statusName;
    this.paginator.changePageToFirst(event);
    this.setRequestBody();
  }

  clearData() {
    this.isNetworkDisabled = true;
    this.isModuleDisabled = true;
    this.isRegionDisabled = true;
    this.isBranchDisabled = true;
    this.circleName = '';
    this.networkName = null;
    this.moduleName = '';
    this.regionName = null;
    this.branchName = '';
    this.offset = 1;
    this.statusType = '';
    this.rowNo = 1;
    this.isNeverLoggedIn = false;
    this.paginator.changePageToFirst(event);
    this.fromDate = new Date(new Date().setFullYear(new Date().getFullYear() - 1));
    this.toDate = new Date();
    this.setRequestBody();
  }

  getNeverLoggedInData() {
    this.service.getNeverLoggedUserDetails(this.apiRequest).subscribe(response => {
      if (response) {
        console.log(response);
        this.userList = response.userResponse;
        this.totalRecords = response.count;
      }
    })
  }

  getInspectionsDoneData() {
    this.service.getInspectionDoneDetails(this.apiRequest).subscribe(response => {
      if (response) {
        console.log(response);
        this.userList = response.inspectionList;
        this.totalRecords = response.count;
      }
    })
  }

  getInspectionsNotDoneData() {
    this.service.getInspectionNotDoneDetails(this.apiRequest).subscribe(response => {
      if (response) {
        console.log(response);
        this.userList = response.inspectionList;
        this.totalRecords = response.count;
      }
    })
  }

  getLoggedInData() {
    this.service.getLoggedInDetails(this.apiRequest).subscribe(response => {
      if (response) {
        console.log(response);
        this.userList = response.inspectionList;
        this.totalRecords = response.count;
      }
    })
  }

  getNotLoggedInData() {
    this.service.getNotLoggedInDetails(this.apiRequest).subscribe(response => {
      if (response) {
        console.log(response);
        this.userList = response.inspectionList;
        this.totalRecords = response.count;
      }
    })
  }

  setRequestBody() {
    if (this.isValidationComplete) {
      this.apiRequest = { "limit": this.limit, "offset": this.offset, "order_by": "asc" };
      if (this.statusType == "Never Logged in Users") {
        if (this.circleName && this.circleName != "All") {
          this.apiRequest.circleName = this.circleName;
        }
        if (this.moduleName && this.moduleName != "All") {
          this.apiRequest.moduleName = this.moduleName;
        }
        if (this.networkName && this.networkName != "All") {
          this.apiRequest.networkId = this.networkName;
        } else {
          if (this.networkName != null && this.networkName.toString() == "0") {
            this.apiRequest.networkId = this.networkName;
          }
        }
        if (this.regionName && this.regionName != "All") {
          this.apiRequest.regId = this.regionName;
        } else {
          if (this.regionName != null && this.regionName.toString() == "0") {
            this.apiRequest.regId = this.regionName;
          }
        }
        if (this.branchName && this.branchName != "All") {
          this.apiRequest.branchCode = this.branchName;
        }
        this.isNeverLoggedIn = true;
        this.apiRequest.sort_by = "firstName";
        this.getNeverLoggedInData();
      } else {
        if (this.circleName && this.circleName != "All") {
          this.apiRequest.circleName = this.circleName;
        }
        if (this.moduleName && this.moduleName != "All") {
          this.apiRequest.moduleName = this.moduleName;
        }
        if (this.networkName && this.networkName != "All") {
          this.apiRequest.networkId = this.networkName;
        }else {
          if (this.networkName != null && this.networkName.toString() == "0") {
            this.apiRequest.networkId = this.networkName;
          }
        }
        if (this.regionName && this.regionName != "All") {
          this.apiRequest.regId = this.regionName;
        }else {
          if (this.regionName != null && this.regionName.toString() == "0") {
            this.apiRequest.regId = this.regionName;
          }
        }
        if (this.branchName && this.branchName != "All") {
          this.apiRequest.branchCode = this.branchName;
        }
        if (this.statusType == "Inspections Done" || this.statusType == '') {
          this.isNeverLoggedIn = false;
          this.apiRequest.sort_by = "status";
          if (this.fromDate) {
            this.apiRequest.fromDate = new Date(this.fromDate).getTime();
          }
          if (this.toDate) {
            this.apiRequest.toDate = new Date(this.toDate).getTime();
          }
          this.getInspectionsDoneData();
        } else if (this.statusType == "Inspections Not Done") {
          this.isNeverLoggedIn = false;
          this.apiRequest.sort_by = "status";
          if (this.fromDate) {
            this.apiRequest.fromDate = new Date(this.fromDate).getTime();
          }
          if (this.toDate) {
            this.apiRequest.toDate = new Date(this.toDate).getTime();
          }
          this.getInspectionsNotDoneData();
        } else if (this.statusType == "Logged in Users") {
          this.isNeverLoggedIn = false;
          this.apiRequest.sort_by = "status";
          if (this.fromDate) {
            this.apiRequest.fromDate = new Date(this.fromDate).getTime();
          }
          if (this.toDate) {
            this.apiRequest.toDate = new Date(this.toDate).getTime();
          }
          this.getLoggedInData();
        } else if (this.statusType == "Not Logged in Users") {
          this.isNeverLoggedIn = false;
          this.apiRequest.sort_by = "status";
          if (this.fromDate) {
            this.apiRequest.fromDate = new Date(this.fromDate).getTime();
          }
          if (this.toDate) {
            this.apiRequest.toDate = new Date(this.toDate).getTime();
          }
          this.getNotLoggedInData();
        }
      }
    } else {
      this.isValidationComplete = false;
      this.dateValMsg = 'Please select To Date';
      this.setTimeOut();
    }
  }

  selectFromDate(fromDate) {
    let dateFromAndTo = fromDate;
    let dateConversion = new Date(dateFromAndTo);
    this.maximumToDate = new Date(dateConversion.setDate(dateConversion.getDate() + 365));
    if (this.maximumToDate > new Date()) {
      this.maximumToDate = new Date();
    }
    if (this.toDate > this.maximumToDate) {
      this.toDate = this.maximumToDate;
    }
    if (this.fromDate > this.toDate) {
      this.isValidationComplete = false;
      this.dateValMsg = 'From Date should be less than To Date';
      this.setTimeOut();
    } else {
      this.isValidationComplete = true;
      this.paginator.changePageToFirst(event);
      this.setRequestBody();
    }
  }

  selectToDate(toDate) {
    this.toDate = this.toDate.setDate(toDate.getDate() + 1);
    if (this.fromDate > this.toDate) {
      this.isValidationComplete = false;
      this.dateValMsg = 'From Date should be less than To Date';
      this.setTimeOut();
    } else {
      this.isValidationComplete = true;
      this.paginator.changePageToFirst(event);
      this.setRequestBody();
    }
  }

  paginate(event) {
    const mainDiv = document.getElementById('content-wrapper');
    if (mainDiv) {
      setTimeout(function () {
        mainDiv.scrollTop = 0;
      }, 1)
    }
    this.rowNo = event.first + 1;
    this.offset = event.page + 1;
    this.setRequestBody();
  }

  setTimeOut() {
    setTimeout(() => {
      this.dateValMsg = "";
    }, 3000);
  }

  downloadPDF() {
    this.downloadFile();
    this.service.downloadPDFDetails(this.apiRequest).subscribe(response => {
      if (response) {
        var byteCharacters = atob(response.file);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: 'application/pdf' });
        var filename = this.fileName;
        var fileURL = URL.createObjectURL(blob);
        window.open(fileURL); // if you want to open it in new tab
        FileSaver.saveAs(blob, filename);
      }
    })
  }

  downloadCSV() {
    this.downloadFile();
    this.service.downloadCSVDetails(this.apiRequest).subscribe(response => {
      if (response) {
        var byteCharacters = atob(response.res);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: 'application/csv' });
        var filename = this.fileName;
        var fileURL = URL.createObjectURL(blob);
        window.open(fileURL); // if you want to open it in new tab
        FileSaver.saveAs(blob, filename);
      }
    })
  }

  downloadFile() {
    this.apiRequest = { "sort_by": "firstName", "order_by": "asc" };
    if (this.circleName && this.circleName != "All") {
      this.apiRequest.circleName = this.circleName;
    } else {
      this.apiRequest.circleName = null;
    }
    if (this.moduleName && this.moduleName != "All") {
      this.apiRequest.moduleName = this.moduleName;
    } else {
      this.apiRequest.moduleName = null;
    }
    if (this.networkName && this.networkName != "All") {
      this.apiRequest.networkId = this.networkName;
    } else {
      if (this.networkName != null && this.networkName.toString() == "0") {
        this.apiRequest.networkId = this.networkName;
      } else {
        this.apiRequest.networkId = null;
      }
    }
    if (this.regionName && this.regionName != "All") {
      this.apiRequest.regId = this.regionName;
    } else {
      if (this.regionName != null && this.regionName.toString() == "0") {
        this.apiRequest.regId = this.regionName;
      } else {
        this.apiRequest.regId = null;
      }
    }
    if (this.branchName && this.branchName != "All") {
      this.apiRequest.brId = this.branchName;
    } else {
      this.apiRequest.brId = null;
    }
    if (this.fromDate) {
      this.apiRequest.fromDate = new Date(this.fromDate).getTime();
    }
    if (this.toDate) {
      this.apiRequest.dateTo = new Date(this.toDate).getTime();
    }
    if (this.statusType == "Never Logged in Users") {
      this.apiRequest.status = 'Never_Logged_in_Users';
      this.fileName = 'NeverLoggedInUsers_SME.csv';
    } else if (this.statusType == "Inspections Done" || this.statusType == '') {
      this.apiRequest.status = 'Inspections_Done';
      this.fileName = 'InspectionsDone_SME.csv';
    } else if (this.statusType == "Inspections Not Done") {
      this.apiRequest.status = 'Inspections_Not_Done';
      this.fileName = 'InspectionsNotDone_SME.csv';
    } else if (this.statusType == "Logged in Users") {
      this.apiRequest.status = 'Logged_in_Users';
      this.fileName = 'LoggedinUsers_SME.csv';
    } else if (this.statusType == "Not Logged in Users") {
      this.apiRequest.status = 'Not_Logged_in_Users';
      this.fileName = 'NotLoggedinUsers_SME.csv';
    }
  }
}