import { Routes } from '@angular/router';

import { CountOfUsersComponent } from '../Module/CountOfUsers/countOfUsers.component';
import { ActiveAndInactiveComponent } from '../Module/ActiveAndInactive/activeAndInactive.component';
import { InspectionDoneComponent } from '../Module/InspectionDone/inspectionDone.component';
import { GridViewComponent } from '../Module/CountOfUsers/GridView/gridView.component';
import { GraphViewComponent } from '../Module/CountOfUsers/GraphView/graphView.component';
import { AllGridViewComponent } from '../Module/CountOfUsers/GridView/All/all.component';
import { SMEGridViewComponent } from '../Module/CountOfUsers/GridView/SME/SME.component';

import { ActiveAndInactiveGridViewComponent } from '../Module/ActiveAndInactive/GridView/gridView.component';
import { ActiveAndInactiveGraphViewComponent } from '../Module/ActiveAndInactive/GraphView/graphView.component';
import { ActiveAndInactiveAllGridViewComponent } from '../Module/ActiveAndInactive/GridView/All/all.component';
import { ActiveAndInactiveSMEGridViewComponent } from '../Module/ActiveAndInactive/GridView/SME/SME.component';
import { InspectionDoneGridViewComponent } from '../Module/InspectionDone/GridView/gridView.component';
import { InspectionDoneGraphViewComponent } from '../Module/InspectionDone/GraphView/graphView.component';
import { InspectionDoneAllGridViewComponent } from '../Module/InspectionDone/GridView/All/all.component';
import { InspectionDoneSMEGridViewComponent } from '../Module/InspectionDone/GridView/SME/SME.component';
import { InspectionDoneSMEGraphViewComponent } from '../Module/InspectionDone/GraphView/SME/SME.component';
import { InspectionDoneAllGraphViewComponent } from '../Module/InspectionDone/GraphView/All/all.component';

export const routes: Routes = [
    {
        path: 'inspectionDone',
        component: InspectionDoneComponent,
        children: [
            {
                path: 'gridView',
                component: InspectionDoneGridViewComponent,
                children: [
                  {
                    path: 'all',
                    component: InspectionDoneAllGridViewComponent
                  },
                  {
                    path: 'SME',
                    component: InspectionDoneSMEGridViewComponent
                  },
                  {
                    path: '',
                    redirectTo: 'all',
                    pathMatch: 'full'
                }
                ]
            },
            {
                path: 'graphView',
                component: InspectionDoneGraphViewComponent,
                children: [
                  {
                    path: 'all',
                    component: InspectionDoneAllGraphViewComponent
                  },
                  {
                    path: 'SME',
                    component: InspectionDoneSMEGraphViewComponent
                  },
                  {
                    path: '',
                    redirectTo: 'all',
                    pathMatch: 'full'
                }
                ]
            },
            {
                path: '',
                redirectTo: 'gridView',
                pathMatch: 'full'
            }
            
        ]
    },
    {
        path: 'countOfUsers',
        component: CountOfUsersComponent,
        children: [
            {
                path: 'gridView',
                component: GridViewComponent,
                children: [
                  {
                    path: 'all',
                    component: AllGridViewComponent
                  },
                  {
                    path: 'SME',
                    component: SMEGridViewComponent
                  },
                  {
                    path: '',
                    redirectTo: 'all',
                    pathMatch: 'full'
                }
                ]
            },
            {
                path: 'graphView',
                component: GraphViewComponent
            },
            {
                path: '',
                redirectTo: 'gridView',
                pathMatch: 'full'
            }
            
        ]
    },
    {
        path: 'activeAndInactive',
        component: ActiveAndInactiveComponent,
        children: [
            {
                path: 'gridView',
                component: ActiveAndInactiveGridViewComponent,
                children: [
                  {
                    path: 'all',
                    component: ActiveAndInactiveAllGridViewComponent
                  },
                  {
                    path: 'SME',
                    component: ActiveAndInactiveSMEGridViewComponent
                  },
                  {
                    path: '',
                    redirectTo: 'all',
                    pathMatch: 'full'
                }
                ]
            },
            {
                path: 'graphView',
                component: ActiveAndInactiveGraphViewComponent
            },
            {
                path: '',
                redirectTo: 'gridView',
                pathMatch: 'full'
            }
            
        ]
    },
    {
        path: '',
        redirectTo: 'inspectionDone',
        pathMatch: 'full'
    },
    {
        path: '**',
        redirectTo: 'inspectionDone',
        pathMatch: 'full'
    }
];